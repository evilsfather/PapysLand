# Changelog

## 1.0.4 — Maintenance, stabilité & mises à jour

PapysLand continue d'évoluer avec une priorité : **faire progresser le modpack sans sacrifier sa stabilité**.

Cette version met à jour plusieurs dépendances après une phase de test dédiée et apporte une nouvelle solution pour la caméra de construction.

### 🔄 Dépendances mises à jour

- **Build Hotbar** : 0.7.1 → **0.8.0**
- **Warfare** : 1.9.0 → **1.9.1**
- **ConditionalConfigSync** : 1.0.5 → **1.0.6**
- **EpicLoot** : 0.14.4 → **0.14.5**
- **ValheimVisualEnhanced** : 0.5.9 → **0.5.10**
- **PotalMap** : 0.1.78 → **0.1.79**
- **Carturs Map Pins** : 1.2.0 → **1.2.2**
- **Carturs Compass and Clock** : 1.1.0 → **1.1.2**
- **ServersideQoL** : 2.0.7 → **2.0.10**
- **ServersideQoL AutoStore** : 2.0.0 → **2.0.8**

### 🎥 Nouvelle caméra de construction

- Suppression de **ValheimBuildCamera 0.1.11**.
- Ajout de **MyBuildCamera 1.0.6 by EndoCo**.
- La caméra de construction est configurée sur la touche **B**.
- **Build Hotbar 0.8.0** conserve la touche **F6**.

Ce changement élimine le conflit de raccourci présent en 1.0.3, où Build Hotbar et ValheimBuildCamera pouvaient utiliser la même touche.

### 🧪 Tests effectués

La combinaison mise à jour a été testée dans un profil dédié avant préparation de cette version.

Tests validés :

- lancement du jeu ;
- menu principal PapysLand ;
- sélection du personnage ;
- entrée en partie ;
- Grand Livre et progression des quêtes ;
- EpicLoot 0.14.5 ;
- redémarrage du jeu sans popup **OUTDATED CONFIGS** observée ;
- caméra de construction ;
- Build Hotbar ;
- systèmes de qualité de vie et stockage testés.

### 📖 Systèmes PapysLand conservés

Les éléments majeurs de PapysLand restent en place :

- **Grand Livre PapysLand V8**
- **2 500 quêtes** : 150 principales + 2 350 secondaires
- **PapysLand VSG QoL 0.3.6**
- **PapysLand Menu 0.4.0 — Saison 1**
- patch EpicLoot PapysLand
- configurations PapysLand essentielles

Cette mise à jour reste dans l'esprit du projet :

**faire évoluer PapysLand progressivement, tester les changements et conserver une aventure cohérente et jouable.**

---

## 1.0.3

- Ajout de **PapysLand Menu 0.4.0** comme dépendance officielle du modpack.

- Ajout de l'identité visuelle **PapysLand — Saison 1** au menu principal et à l'écran de sélection du personnage.

- Remplacement de **Build_Camera_Unofficial_Valheim_1_0_Fix 1.2.0** par **Stonaar ValheimBuildCamera 0.1.11**.

- **ValheimBuildCamera** s'active avec **F6** lorsque le marteau est équipé.

- Suppression de **Balrond Shipyard 1.6.7**, identifié pendant les tests comme source des erreurs Unity « Cannot instantiate objects with a parent which is persistent ».

- Le décor 3D animé, la caméra, les transitions et l'interface d'origine de Valheim restent inchangés par PapysLand Menu.

- Le **Grand Livre V8**, ses **2 500 quêtes**, **PapysLand VSG QoL 0.3.6**, le patch EpicLoot et les autres configurations PapysLand restent inchangés.

- Le nombre total de dépendances reste à **38** : 2 dépendances retirées et 2 ajoutées.

---

## 1.0.2

- Correction du README : suppression du titre resté en version 1.0.0.

- Mise à jour de la présentation, des instructions d'installation et des versions de référence.

- Documentation du patch EpicLoot introduit en 1.0.1 et des résultats des tests.

- Ajout du problème Unity connu et des limites de validation.

- Mise à jour documentaire uniquement : aucun changement des mods, de leurs versions, des configurations ou des quêtes par rapport à la 1.0.1.

---

## 1.0.1

- Remplacement du fichier EpicLoot adventuredata.json complet par un patch PapysLand utilisant les configurations de base d'EpicLoot 0.14.4.

- Ajout de 260 entrées GambleCosts personnalisées via ce patch.

- Suppression ciblée de l'entrée ArmorBerserkerLegs à 999 pièces ; conservation de celle à 400 pièces.

- Correction OUTDATED CONFIGS validée sur un profil vierge avec les 38 dépendances : deux démarrages sans popup, présence des ajouts PapysLand et une seule entrée ArmorBerserkerLegs à 400 pièces.

- PapysLand VSG QoL 0.3.6 chargé correctement ; Grand Livre accessible et deux quêtes testées avec succès.

- Aucun changement des 38 dépendances ni de leurs versions.

- Grand Livre V8 et PapysLand VSG QoL 0.3.6 inchangés.

- Problème connu : messages Unity « Cannot instantiate objects with a parent which is persistent » au chargement d'une partie, également reproduits en 1.0.0. Aucun blocage observé pendant les essais ; cause et impact complet non déterminés.

---

## 1.0.0

- Première publication publique de **PapysLand Modpack**.

- 37 mods sélectionnés + **PapysLand VSG QoL 0.3.6** comme dépendance officielle.

- Grand Livre PapysLand V8 : **2 500 quêtes** (150 principales + 2 350 secondaires).

- Configurations PapysLand essentielles intégrées.

- Configuration EpicLoot personnalisée conservée.

- Suppression des sauvegardes/progressions personnelles et des résidus connus de mods retirés ou incompatibles.

- PapysLand VSG QoL n'est plus embarqué en DLL dans le modpack : il est installé proprement via Thunderstore.