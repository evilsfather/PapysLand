![PapysLand Banner](https://github.com/evilsfather/PapysLand/blob/main/images/papysland-banner.png?raw=true)

# PapysLand Modpack

## Plus qu'un jeu… un monde à notre image.

**PapysLand — made by PapyDiablo** est un modpack Valheim pensé pour enrichir l'aventure, la construction, l'exploration et la progression sans transformer le jeu en enfer artificiellement difficile.

L'objectif n'est pas d'empiler des mods pour le simple plaisir d'en avoir beaucoup.

L'objectif est de construire un monde cohérent, vivant, agréable à parcourir et suffisamment riche pour donner envie de revenir encore et encore.

**Explorer. Construire. Combattre. Progresser. Découvrir. Survivre.**

Bienvenue à **PapysLand**.

---

# 🔥 L'esprit PapysLand

PapysLand conserve l'âme de Valheim tout en ajoutant davantage de possibilités :

- exploration enrichie ;
- nombreux lieux et donjons ;
- construction largement étendue ;
- progression RPG ;
- loot amélioré ;
- nouvelles possibilités de combat ;
- qualité de vie ;
- plongée et exploration sous-marine ;
- plantation et aménagement du terrain ;
- 2 500 quêtes ;
- identité visuelle PapysLand ;
- systèmes pensés pour accompagner une longue aventure.

Le but reste simple :

> **Ajouter du contenu sans supprimer le plaisir de progresser.**

---

![Le Grand Livre PapysLand](https://github.com/evilsfather/PapysLand/blob/main/images/papysland-grand-livre.png?raw=true)

# 📖 Le Grand Livre PapysLand

Au cœur du modpack se trouve le **Grand Livre PapysLand V8**.

Il contient :

- **150 quêtes principales**
- **2 350 quêtes secondaires**
- soit **2 500 quêtes au total**

Le fichier de quêtes est fourni dans :

`BepInEx/config/ValheimServerGuide/guidance.yaml`

Les quêtes accompagnent la progression et encouragent :

- l'exploration ;
- la construction ;
- la découverte ;
- le combat ;
- la survie ;
- la progression ;
- l'utilisation des différents systèmes du modpack.

PapysLand n'inclut aucune progression personnelle de joueur.

**Chaque joueur commence sa propre aventure.**

---

![Exploration PapysLand](https://github.com/evilsfather/PapysLand/blob/main/images/papysland-exploration.png?raw=true)

# 🌍 Un monde qui mérite d'être exploré

PapysLand donne davantage de raisons de quitter sa base et de partir à l'aventure.

Le modpack enrichit notamment :

- les lieux à découvrir ;
- les donjons ;
- les biomes ;
- les points d'intérêt ;
- les océans ;
- l'exploration terrestre ;
- l'exploration sous-marine ;
- les longues expéditions ;
- les récompenses liées à la découverte.

La progression ne se résume plus seulement à aller chercher le prochain boss.

Il y a toujours quelque chose à trouver, construire ou améliorer.

---

![Construction PapysLand](https://github.com/evilsfather/PapysLand/blob/main/images/papysland-construction.png?raw=true)

# 🔨 Construisez votre PapysLand

La construction occupe une place très importante dans le modpack.

PapysLand améliore notamment :

- les possibilités de construction ;
- la décoration ;
- le terrassement ;
- la plantation ;
- l'aménagement du terrain ;
- la gestion des matériaux ;
- la rapidité de construction ;
- la liberté de placement.

Parmi les outils intégrés :

- **Build Hotbar**
- **MyBuildCamera**
- **PlantEverything**
- **CraftFromChests**
- **DigDeeper**
- **Plateautem**
- **Balrond Constructions**
- et plusieurs améliorations de qualité de vie.

## 🎥 Caméra de construction

PapysLand 1.0.4 utilise :

**MyBuildCamera 1.0.6 by EndoCo**

Avec un marteau ou un outil de construction équipé :

**B = activer / désactiver la caméra de construction**

La caméra permet de se déplacer librement autour de sa construction afin de placer plus facilement les pièces complexes.

---

![Combat RPG PapysLand](https://github.com/evilsfather/PapysLand/blob/main/images/papysland-combat-rpg.png?raw=true)

# ⚔️ Combat • Butin • Progression

PapysLand ajoute également une couche RPG plus importante à Valheim.

Parmi les principaux systèmes intégrés :

- **EpicLoot**
- **Warfare**
- **SkillsReworked**
- **DualMastery**
- **CreatureManager**
- **Max Dungeon Rooms**
- équipements rares et améliorés ;
- progression des compétences ;
- exploration de donjons ;
- combats plus variés ;
- récompenses plus intéressantes.

L'objectif n'est pas de rendre chaque combat injustement difficile.

L'objectif est de rendre la progression plus intéressante et plus gratifiante.

---

# 🛡️ Un modpack vivant

PapysLand est fait pour durer.

Le projet continuera d'évoluer au fil de Valheim, des mises à jour et de mes idées.

Mais évoluer ne signifie pas installer chaque nouveau mod simplement parce qu'il existe.

Chaque ajout doit avoir une raison d'être.

Chaque changement important est testé avant d'intégrer la version publique.

Un mod instable peut être remplacé ou retiré, même s'il apporte une fonctionnalité intéressante.

L'objectif est de construire, version après version, une aventure toujours plus riche tout en conservant une base jouable et stable.

De nouvelles quêtes, de nouvelles idées, de nouvelles aventures et peut-être de nouvelles saisons viendront continuer l'histoire de PapysLand.

**Ce monde n'est pas terminé.**

**L'aventure ne fait que commencer.**

— **PapyDiablo**

---

# 🧪 Philosophie de stabilité

PapysLand n'est pas mis à jour automatiquement dès qu'une nouvelle version d'un mod apparaît.

Les mises à jour importantes sont d'abord testées dans un profil dédié.

Cette méthode permet de vérifier notamment :

- le lancement du jeu ;
- les menus ;
- les quêtes ;
- EpicLoot ;
- la construction ;
- les raccourcis clavier ;
- les systèmes QoL ;
- AutoStore ;
- la compatibilité entre les différents mods ;
- l'absence d'erreurs majeures.

Une version publique n'est publiée qu'une fois la combinaison considérée suffisamment stable.

---

# 📦 PapysLand 1.0.4

La version **1.0.4** actualise plusieurs dépendances importantes et remplace l'ancienne caméra de construction par une solution plus fiable.

Parmi les changements principaux :

- EpicLoot → **0.14.5**
- ConditionalConfigSync → **1.0.6**
- Warfare → **1.9.1**
- Build Hotbar → **0.8.0**
- ServersideQoL → **2.0.10**
- ServersideQoL AutoStore → **2.0.8**
- PotalMap → **0.1.79**
- Carturs Map Pins → **1.2.2**
- Carturs Compass and Clock → **1.1.2**
- ValheimVisualEnhanced → **0.5.10**
- MyBuildCamera → **1.0.6**

**ValheimBuildCamera a été retiré.**

---

# 🧰 Contenu principal

PapysLand comprend notamment :

- **Grand Livre PapysLand V8**
- **2 500 quêtes**
- **EpicLoot**
- **Warfare**
- **SkillsReworked**
- **DualMastery**
- **More World Locations AIO**
- **OreMines**
- **Balrond Constructions**
- **Balrond MonsterMayhem**
- **Build Hotbar**
- **MyBuildCamera**
- **PlantEverything**
- **PlantEasily**
- **Dive In**
- **PotalMap**
- **Carturs Map Pins**
- **Carturs Compass and Clock**
- **Backpacks**
- **CraftFromChests**
- **ServersideQoL**
- **ServersideQoL AutoStore**
- **PapysLand VSG QoL**
- **PapysLand Menu**
- et de nombreux autres systèmes complémentaires.

La liste complète des dépendances et de leurs versions se trouve dans le `manifest.json`.

---

# 🎨 PapysLand Menu — Saison 1

PapysLand possède sa propre identité visuelle grâce à :

**PapysLand Menu 0.4.0**

Le plugin ajoute l'identité PapysLand :

- sur le menu principal ;
- sur la sélection du personnage.

Le décor 3D animé original de Valheim est conservé.

Les transitions, les boutons et la caméra du menu restent ceux du jeu.

---

# 📚 PapysLand VSG QoL

Le modpack utilise :

**PapysLand VSG QoL 0.3.6**

Cette dépendance officielle PapysLand améliore le fonctionnement du système de quêtes et intègre notamment les protections nécessaires au Grand Livre.

---

# 💎 Configuration EpicLoot

Les personnalisations PapysLand pour EpicLoot sont distribuées sous forme de patch dans :

`BepInEx/config/EpicLoot/patches/`

PapysLand ne distribue pas le fichier complet :

`BepInEx/config/EpicLoot/baseconfig/adventuredata.json`

Cette méthode permet de conserver les ajouts PapysLand tout en utilisant la configuration de base d'EpicLoot.

PapysLand 1.0.4 utilise :

**EpicLoot 0.14.5**

---

# 🎮 Installation

L'installation recommandée se fait avec **r2modman**.

1. Créez un profil dédié à PapysLand.
2. Recherchez **PapysLand_Modpack** par **PapyDiablo**.
3. Installez le modpack avec toutes ses dépendances.
4. Lancez le jeu avec **Start modded**.
5. Commencez de préférence une nouvelle aventure pour profiter pleinement de l'expérience.

Pour conserver la combinaison testée, utilisez les versions définies par le modpack.

Une mise à jour individuelle d'une dépendance peut modifier le comportement de l'ensemble.

---

# ⌨️ Touches importantes

## Build Hotbar

**F6**  
Affiche ou masque la barre de construction.

## MyBuildCamera

**B**  
Active ou désactive la caméra libre de construction lorsqu'un marteau est équipé.

Les touches peuvent être modifiées dans le gestionnaire de configuration si nécessaire.

---

# 📌 Versions de référence

PapysLand 1.0.4 utilise notamment :

- BepInExPack Valheim **5.4.2350**
- YamlDotNet **16.3.1**
- JsonDotNET **13.0.4**
- Jötunn **2.30.0**
- EpicLoot **0.14.5**
- Warfare **1.9.1**
- ValheimServerGuide **0.16.1**
- Build Hotbar **0.8.0**
- MyBuildCamera **1.0.6**
- ConditionalConfigSync **1.0.6**
- ServersideQoL **2.0.10**
- ServersideQoL AutoStore **2.0.8**
- PapysLand VSG QoL **0.3.6**
- PapysLand Menu **0.4.0**

La liste complète et exacte se trouve dans le manifeste du modpack.

---

# 🗃️ Archives et développement

Le projet PapysLand possède maintenant son dépôt officiel :

**GitHub — evilsfather/PapysLand**

Le dépôt contient :

- les images officielles ;
- les anciennes versions ;
- les fichiers `manifest.json` ;
- les README ;
- les changelogs ;
- les archives ZIP ;
- les futurs documents PapysLand.

Il sert de base de travail et d'archive afin que chaque version puisse être conservée.

---

# 📜 Historique des versions

Consultez l'onglet **Changelog** pour connaître les changements détaillés.

Les anciennes versions sont également archivées sur le dépôt GitHub officiel.

---

# ❤️ Merci

PapysLand est développé et maintenu avec l'envie de créer une aventure Valheim différente sans perdre ce qui rend le jeu agréable.

Merci à toutes les personnes qui téléchargent, testent et jouent au modpack.

Chaque téléchargement donne une raison supplémentaire de continuer à faire évoluer ce monde.

---

# PAPYSLAND

## Plus qu'un jeu… un monde à notre image.

**Made by PapyDiablo.**